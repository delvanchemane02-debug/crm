import React, { useState, useEffect } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Plus, Trash2, Edit2, Download, Eye, EyeOff } from 'lucide-react';

const LogoErganomika = () => (
  <svg width="140" height="50" viewBox="0 0 140 50" fill="none" xmlns="http://www.w3.org/2000/svg">
    <text x="0" y="35" fontSize="28" fontWeight="600" fill="#D4AF37" fontFamily="Arial, sans-serif">Ergonómica</text>
    <text x="0" y="48" fontSize="9" fontWeight="400" fill="#888888" fontFamily="Arial, sans-serif" letterSpacing="1">HIGH-TECH FURNITURE</text>
    <circle cx="125" cy="15" r="8" fill="#D4AF37" opacity="0.2" />
  </svg>
);

const CRMApp = () => {
  const [propostas, setPropostas] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [filterEstado, setFilterEstado] = useState('Todos');
  const [filterOrigem, setFilterOrigem] = useState('Todos');
  const [formData, setFormData] = useState({
    numero: '', cliente: '', contacto: '', telefone: '', servico: '',
    valor: '', custo: '', probabilidade: '', estado: 'Enviada', 
    origem: 'Indicação', proxima: '', fecho: '', observacoes: ''
  });

  useEffect(() => {
    const saved = localStorage.getItem('crm_propostas');
    if (saved) {
      setPropostas(JSON.parse(saved));
    } else {
      setPropostas([
        { id: 1, numero: 'ERG-2026-001', cliente: 'Beatriz Dai', contacto: 'Beatriz', telefone: '+258 84 1234567', servico: 'Estores de rolo', valor: 8526, custo: 4500, probabilidade: 75, estado: 'Negociação', origem: 'Indicação', proxima: '2026-02-05', fecho: '2026-02-20', observacoes: 'Cliente interessado' },
        { id: 2, numero: 'ERG-2026-002', cliente: 'Enh Serviços', contacto: 'João Silva', telefone: '+258 84 2345678', servico: 'Capainha', valor: 54769, custo: 28000, probabilidade: 50, estado: 'Em Análise', origem: 'Website', proxima: '2026-02-01', fecho: '2026-03-15', observacoes: 'Aguardando aprovação interna' },
        { id: 3, numero: 'ERG-2026-003', cliente: 'A Cavale Advogado', contacto: 'Dr. Cavale', telefone: '+258 84 3456789', servico: 'Design de Escritório', valor: 15789, custo: 7500, probabilidade: 90, estado: 'Aguardando Aprovação', origem: 'Cliente Recorrente', proxima: '2026-02-03', fecho: '2026-02-10', observacoes: 'Projeto já aprovado' },
        { id: 4, numero: 'ERG-2026-004', cliente: 'RB Obras', contacto: 'Roberto', telefone: '+258 84 4567890', servico: 'Mesas e Cadeiras', valor: 140769, custo: 65000, probabilidade: 75, estado: 'Aprovada', origem: 'Networking', proxima: '2026-02-08', fecho: '2026-02-08', observacoes: 'Projeto grande, em execução' },
        { id: 5, numero: 'ERG-2026-005', cliente: 'Galo da Mulata', contacto: 'Gerente Operações', telefone: '+258 84 5678901', servico: 'Equipamento de Cozinha', valor: 353059, custo: 180000, probabilidade: 90, estado: 'Aprovada', origem: 'Cliente Recorrente', proxima: '2026-02-01', fecho: '2026-02-01', observacoes: 'Maior cliente, contrato anual' },
        { id: 6, numero: 'ERG-2026-006', cliente: 'UBA', contacto: 'Chefe de Compras', telefone: '+258 84 6789012', servico: 'Estantes Metálicas', valor: 79286, custo: 42000, probabilidade: 25, estado: 'Em Análise', origem: 'Concurso Público', proxima: '2026-02-10', fecho: '2026-03-30', observacoes: 'Concurso público, muita concorrência' },
        { id: 7, numero: 'ERG-2026-007', cliente: 'Kingo Corporation', contacto: 'Responsável Logística', telefone: '+258 84 7890123', servico: 'Armazenamento, Transporte', valor: 13831, custo: 6000, probabilidade: 50, estado: 'Enviada', origem: 'Parceiro', proxima: '2026-02-02', fecho: '2026-03-01', observacoes: 'Proposta recente' },
        { id: 8, numero: 'ERG-2026-008', cliente: 'Vista Bank', contacto: 'Diretor RH', telefone: '+258 84 8901234', servico: 'Cadeiras Executivas', valor: 1215000, custo: 600000, probabilidade: 10, estado: 'Em Análise', origem: 'Indicação', proxima: '2026-02-06', fecho: '2026-06-30', observacoes: 'Projeto grande, decisão lenta' }
      ]);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('crm_propostas', JSON.stringify(propostas));
  }, [propostas]);

  const generateNumber = () => {
    const year = new Date().getFullYear();
    const count = propostas.filter(p => p.numero.startsWith(`ERG-${year}`)).length + 1;
    return `ERG-${year}-${String(count).padStart(3, '0')}`;
  };

  const handleSave = () => {
    if (!formData.cliente || !formData.valor) {
      alert('Preencha cliente e valor');
      return;
    }
    if (editingId) {
      setPropostas(propostas.map(p => p.id === editingId ? { ...p, ...formData } : p));
      setEditingId(null);
    } else {
      setPropostas([...propostas, { 
        ...formData, 
        id: Math.max(...propostas.map(p => p.id || 0), 0) + 1, 
        numero: formData.numero || generateNumber(),
        valor: parseFloat(formData.valor),
        custo: parseFloat(formData.custo) || 0
      }]);
    }
    setFormData({ numero: '', cliente: '', contacto: '', telefone: '', servico: '', valor: '', custo: '', probabilidade: '', estado: 'Enviada', origem: 'Indicação', proxima: '', fecho: '', observacoes: '' });
    setShowForm(false);
  };

  const handleEdit = (p) => {
    setFormData(p);
    setEditingId(p.id);
    setShowForm(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza?')) {
      setPropostas(propostas.filter(p => p.id !== id));
    }
  };

  const exportToExcel = () => {
    const csv = 'Nº Proposta,Cliente,Serviço,Valor (MT),Custo (MT),Lucro (MT),Margem %,Probabilidade,Estado,Origem,Data Fecho\n' +
      propostas.map(p => {
        const lucro = p.valor - p.custo;
        const margem = ((lucro / p.valor) * 100).toFixed(1);
        return `${p.numero},"${p.cliente}","${p.servico}",${p.valor},${p.custo},${lucro},${margem}%,${p.probabilidade}%,"${p.estado}","${p.origem}",${p.fecho}`;
      }).join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `CRM_Ergonomica_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const filtradas = propostas.filter(p => 
    (filterEstado === 'Todos' || p.estado === filterEstado) &&
    (filterOrigem === 'Todos' || p.origem === filterOrigem)
  );

  const totalValor = filtradas.reduce((s, p) => s + p.valor, 0);
  const totalAprovado = filtradas.filter(p => p.estado === 'Aprovada').reduce((s, p) => s + p.valor, 0);
  const totalAberto = filtradas.filter(p => !['Aprovada', 'Perdida', 'Cancelada'].includes(p.estado)).reduce((s, p) => s + p.valor, 0);
  const pipelinePonderado = filtradas.reduce((s, p) => s + (p.valor * p.probabilidade / 100), 0);

  const estadoData = ['Aprovada', 'Negociação', 'Em Análise', 'Enviada', 'Aguardando Aprovação'].map(e => ({
    name: e,
    count: propostas.filter(p => p.estado === e).length,
    valor: propostas.filter(p => p.estado === e).reduce((s, p) => s + p.valor, 0)
  }));

  return (
    <div style={{ minHeight: '100vh', background: '#fafafa', padding: '0' }}>
      {/* Header com Logotipo */}
      <div style={{ background: 'white', borderBottom: '2px solid #D4AF37', padding: '16px 20px', boxShadow: '0 2px 8px rgba(212, 175, 55, 0.1)' }}>
        <div style={{ maxWidth: '1400px', margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <LogoErganomika />
          <div style={{ fontSize: '12px', color: '#888', fontStyle: 'italic' }}>Dashboard de Vendas</div>
        </div>
      </div>

      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '30px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
          <div>
            <h1 style={{ fontSize: '28px', fontWeight: '600', margin: 0, color: '#333' }}>Propostas e Vendas</h1>
            <p style={{ color: '#999', margin: '8px 0 0 0', fontSize: '14px' }}>Gerencie suas propostas comerciais</p>
          </div>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button onClick={exportToExcel} style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 16px', background: '#ffffff', border: '2px solid #D4AF37', borderRadius: '8px', cursor: 'pointer', fontSize: '14px', fontWeight: '500', color: '#D4AF37', transition: 'all 0.3s' }}>
              <Download size={18} /> Exportar
            </button>
            <button onClick={() => { setShowForm(!showForm); setEditingId(null); }} style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 16px', background: '#D4AF37', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', fontSize: '14px', fontWeight: '500' }}>
              <Plus size={18} /> Nova Proposta
            </button>
          </div>
        </div>

        {showForm && (
          <div style={{ background: 'white', padding: '20px', borderRadius: '12px', marginBottom: '30px', border: '2px solid #D4AF37' }}>
            <h3 style={{ margin: '0 0 16px 0', color: '#D4AF37', borderBottom: '2px solid #D4AF37', paddingBottom: '8px' }}>{editingId ? 'Editar Proposta' : 'Nova Proposta'}</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '12px', marginBottom: '16px' }}>
              <input placeholder="Nº Proposta" value={formData.numero} onChange={(e) => setFormData({...formData, numero: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }} />
              <input placeholder="Cliente" value={formData.cliente} onChange={(e) => setFormData({...formData, cliente: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }} />
              <input placeholder="Contacto" value={formData.contacto} onChange={(e) => setFormData({...formData, contacto: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }} />
              <input placeholder="Telefone" value={formData.telefone} onChange={(e) => setFormData({...formData, telefone: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }} />
              <input placeholder="Serviço" value={formData.servico} onChange={(e) => setFormData({...formData, servico: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }} />
              <input placeholder="Valor (MT)" type="number" value={formData.valor} onChange={(e) => setFormData({...formData, valor: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }} />
              <input placeholder="Custo (MT)" type="number" value={formData.custo} onChange={(e) => setFormData({...formData, custo: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }} />
              <input placeholder="Probabilidade (%)" type="number" value={formData.probabilidade} onChange={(e) => setFormData({...formData, probabilidade: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }} />
              <select value={formData.estado} onChange={(e) => setFormData({...formData, estado: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }}>
                <option>Enviada</option><option>Em Análise</option><option>Negociação</option><option>Aguardando Aprovação</option><option>Aprovada</option><option>Perdida</option>
              </select>
              <select value={formData.origem} onChange={(e) => setFormData({...formData, origem: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }}>
                <option>Indicação</option><option>Cliente Recorrente</option><option>Website</option><option>Networking</option><option>Concurso Público</option><option>Parceiro</option>
              </select>
              <input placeholder="Próxima Acção" type="date" value={formData.proxima} onChange={(e) => setFormData({...formData, proxima: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }} />
              <input placeholder="Data de Fecho" type="date" value={formData.fecho} onChange={(e) => setFormData({...formData, fecho: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }} />
              <input placeholder="Observações" value={formData.observacoes} onChange={(e) => setFormData({...formData, observacoes: e.target.value})} style={{ padding: '8px', borderRadius: '6px', border: '1px solid #ddd', gridColumn: '1 / -1' }} />
            </div>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={handleSave} style={{ padding: '10px 16px', background: '#D4AF37', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: '500', transition: 'all 0.3s' }}>Guardar</button>
              <button onClick={() => { setShowForm(false); setEditingId(null); }} style={{ padding: '10px 16px', background: '#f0f0f0', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: '500' }}>Cancelar</button>
            </div>
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '16px', marginBottom: '30px' }}>
          <div style={{ background: 'white', padding: '16px', borderRadius: '12px', border: '1px solid #e5e5e5', textAlign: 'center', borderLeft: '4px solid #D4AF37' }}>
            <div style={{ fontSize: '12px', color: '#999', marginBottom: '6px', fontWeight: '500' }}>Total de Propostas</div>
            <div style={{ fontSize: '28px', fontWeight: '600', color: '#333' }}>{propostas.length}</div>
          </div>
          <div style={{ background: 'white', padding: '16px', borderRadius: '12px', border: '1px solid #e5e5e5', textAlign: 'center', borderLeft: '4px solid #D4AF37' }}>
            <div style={{ fontSize: '12px', color: '#999', marginBottom: '6px', fontWeight: '500' }}>Valor Total</div>
            <div style={{ fontSize: '24px', fontWeight: '600', color: '#333' }}>{(totalValor / 1000000).toFixed(2)}M MT</div>
          </div>
          <div style={{ background: 'white', padding: '16px', borderRadius: '12px', border: '1px solid #e5e5e5', textAlign: 'center', borderLeft: '4px solid #D4AF37' }}>
            <div style={{ fontSize: '12px', color: '#999', marginBottom: '6px', fontWeight: '500' }}>Em Aberto</div>
            <div style={{ fontSize: '24px', fontWeight: '600', color: '#333' }}>{(totalAberto / 1000000).toFixed(2)}M MT</div>
          </div>
          <div style={{ background: 'white', padding: '16px', borderRadius: '12px', border: '1px solid #e5e5e5', textAlign: 'center', borderLeft: '4px solid #10b981' }}>
            <div style={{ fontSize: '12px', color: '#999', marginBottom: '6px', fontWeight: '500' }}>Aprovado</div>
            <div style={{ fontSize: '24px', fontWeight: '600', color: '#10b981' }}>{(totalAprovado / 1000000).toFixed(2)}M MT</div>
          </div>
          <div style={{ background: 'white', padding: '16px', borderRadius: '12px', border: '1px solid #e5e5e5', textAlign: 'center', borderLeft: '4px solid #D4AF37' }}>
            <div style={{ fontSize: '12px', color: '#999', marginBottom: '6px', fontWeight: '500' }}>Pipeline Ponderado</div>
            <div style={{ fontSize: '24px', fontWeight: '600', color: '#3b82f6' }}>{(pipelinePonderado / 1000000).toFixed(2)}M MT</div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '20px', marginBottom: '30px' }}>
          <div style={{ background: 'white', padding: '20px', borderRadius: '12px', border: '1px solid #e5e5e5', borderTop: '4px solid #D4AF37' }}>
            <h3 style={{ margin: '0 0 16px 0', color: '#333', borderBottom: '2px solid #D4AF37', paddingBottom: '8px' }}>Propostas por Estado</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={estadoData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div style={{ background: 'white', padding: '20px', borderRadius: '12px', border: '1px solid #e5e5e5', borderTop: '4px solid #D4AF37' }}>
            <h3 style={{ margin: '0 0 16px 0', color: '#333', borderBottom: '2px solid #D4AF37', paddingBottom: '8px' }}>Filtros</h3>
            <div style={{ marginBottom: '12px' }}>
              <label style={{ fontSize: '12px', color: '#666', display: 'block', marginBottom: '4px' }}>Estado</label>
              <select value={filterEstado} onChange={(e) => setFilterEstado(e.target.value)} style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }}>
                <option>Todos</option><option>Aprovada</option><option>Negociação</option><option>Em Análise</option><option>Enviada</option><option>Aguardando Aprovação</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: '12px', color: '#666', display: 'block', marginBottom: '4px' }}>Origem</label>
              <select value={filterOrigem} onChange={(e) => setFilterOrigem(e.target.value)} style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #ddd' }}>
                <option>Todos</option><option>Indicação</option><option>Cliente Recorrente</option><option>Website</option><option>Networking</option><option>Concurso Público</option><option>Parceiro</option>
              </select>
            </div>
          </div>
        </div>

        <div style={{ background: 'white', padding: '20px', borderRadius: '12px', border: '1px solid #e5e5e5', borderTop: '4px solid #D4AF37' }}>
          <h3 style={{ margin: '0 0 16px 0', color: '#333', borderBottom: '2px solid #D4AF37', paddingBottom: '8px' }}>Propostas ({filtradas.length})</h3>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
              <thead>
                <tr style={{ borderBottom: '3px solid #D4AF37' }}>
                  <th style={{ textAlign: 'left', padding: '12px', fontWeight: '600', color: '#D4AF37' }}>Nº</th>
                  <th style={{ textAlign: 'left', padding: '12px', fontWeight: '600', color: '#D4AF37' }}>Cliente</th>
                  <th style={{ textAlign: 'left', padding: '12px', fontWeight: '600', color: '#D4AF37' }}>Serviço</th>
                  <th style={{ textAlign: 'right', padding: '12px', fontWeight: '600', color: '#D4AF37' }}>Valor</th>
                  <th style={{ textAlign: 'center', padding: '12px', fontWeight: '600', color: '#D4AF37' }}>Prob.</th>
                  <th style={{ textAlign: 'center', padding: '12px', fontWeight: '600', color: '#D4AF37' }}>Estado</th>
                  <th style={{ textAlign: 'center', padding: '12px', fontWeight: '600', color: '#D4AF37' }}>Ações</th>
                </tr>
              </thead>
              <tbody>
                {filtradas.map((p, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid #eee' }}>
                    <td style={{ padding: '12px', fontWeight: '600' }}>{p.numero}</td>
                    <td style={{ padding: '12px' }}>{p.cliente}</td>
                    <td style={{ padding: '12px', color: '#666' }}>{p.servico}</td>
                    <td style={{ padding: '12px', textAlign: 'right', fontWeight: '500' }}>{(p.valor / 1000).toFixed(0)}K</td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>{p.probabilidade}%</td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>
                      <span style={{ padding: '4px 8px', borderRadius: '4px', fontSize: '12px', fontWeight: '500', background: p.estado === 'Aprovada' ? '#d1fae5' : p.estado === 'Negociação' ? '#fef3c7' : '#dbeafe', color: p.estado === 'Aprovada' ? '#065f46' : p.estado === 'Negociação' ? '#92400e' : '#1e40af' }}>
                        {p.estado}
                      </span>
                    </td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>
                      <button onClick={() => handleEdit(p)} style={{ background: 'none', border: 'none', cursor: 'pointer', marginRight: '8px', color: '#3b82f6' }}><Edit2 size={16} /></button>
                      <button onClick={() => handleDelete(p.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ef4444' }}><Trash2 size={16} /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CRMApp;
