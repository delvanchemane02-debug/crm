import React from 'react';
import ReactDOM from 'react-dom/client';
import CRMApp from './App';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CRMApp />
  </React.StrictMode>
);
