# 🚀 CRM Ergonómica - Deployment em Vercel

Dashboard de Propostas e Vendas da Ergonómica, hospedado em Vercel com atualização automática.

## ✨ Funcionalidades

✅ Dashboard com KPIs automáticos (Total, Em Aberto, Aprovado, Pipeline Ponderado)
✅ Gráficos de propostas por estado
✅ Tabela completa de propostas com filtros (Estado, Origem)
✅ CRUD completo (Adicionar, Editar, Deletar propostas)
✅ Exportar dados para CSV/Excel
✅ Dados salvos localmente (persistem entre sessões)
✅ Funciona offline
✅ Responsivo para mobile
✅ Design profissional

---

## 🔧 Instalação Local (para testes)

### 1. Clonar o repositório

```bash
git clone https://github.com/SEU_USUARIO/crm-ergonomica.git
cd crm-ergonomica
```

### 2. Instalar dependências

```bash
npm install
```

### 3. Executar localmente

```bash
npm start
```

Abre automaticamente em `http://localhost:3000`

### 4. Build para produção

```bash
npm run build
```

Cria pasta `build/` pronta para deployment

---

## 🌐 Deployment em Vercel

### Opção 1: Deploy automático via GitHub (RECOMENDADO)

1. **Criar repositório GitHub**
   - Ir a https://github.com/new
   - Nome: `crm-ergonomica`
   - Public
   - Criar

2. **Enviar código para GitHub**
   ```bash
   git remote set-url origin https://github.com/SEU_USUARIO/crm-ergonomica.git
   git branch -M main
   git push -u origin main
   ```

3. **Conectar Vercel**
   - Ir a https://vercel.com/new
   - Importar repositório `crm-ergonomica`
   - Framework: React
   - Clicar em "Deploy"
   - ✅ Pronto! Link gerado automaticamente

**Resultado**: `https://crm-ergonomica.vercel.app`

### Opção 2: Deploy manual via Vercel CLI

```bash
# Instalar Vercel CLI
npm i -g vercel

# Fazer deploy
vercel

# Deploy para produção
vercel --prod
```

---

## 📊 Como usar

### Dashboard
- **KPIs no topo**: Resumo de valores e pipeline
- **Gráficos**: Propostas por estado
- **Filtros**: Estado e Origem para análise específica

### Adicionar Nova Proposta
1. Clicar em "Nova Proposta"
2. Preencher formulário
3. Clicar em "Guardar"

### Editar Proposta
1. Clicar no ícone "Editar" (lápis) na linha da proposta
2. Alterar dados
3. Clicar em "Guardar"

### Deletar Proposta
1. Clicar no ícone "Deletar" (lixo)
2. Confirmar exclusão

### Exportar para Excel
1. Clicar em "Exportar"
2. CSV gerado com todas as propostas
3. Abrir em Excel/Google Sheets

---

## 📱 Dados Iniciais

O CRM vem com 8 propostas de exemplo (os dados que forneceu):
- Beatriz Dai - 8.5K MT
- Enh Serviços - 54.7K MT
- A Cavale Advogado - 15.7K MT
- RB Obras - 140.7K MT
- Galo da Mulata - 353K MT
- UBA - 79.2K MT
- Kingo Corporation - 13.8K MT
- Vista Bank - 1.215M MT

Pode editar/deletar e adicionar novas propostas livremente.

---

## 💾 Dados & Privacidade

- **Dados salvos localmente** no seu browser (localStorage)
- Nenhum dado é enviado para servidores externos
- Dados persistem entre sessões
- Pode exportar em qualquer momento

---

## 🔄 Atualizações Automáticas

Sempre que fazer push para GitHub:
```bash
git add .
git commit -m "Atualização do CRM"
git push
```

Vercel detecta automaticamente e faz deploy da nova versão (2-3 minutos).

---

## 🆘 Troubleshooting

### "npm: command not found"
Instale Node.js: https://nodejs.org/

### Erro ao fazer npm install
```bash
rm -rf node_modules package-lock.json
npm install
```

### Dashboard não carrega em Vercel
Limpar cache do browser (Ctrl+Shift+Del ou Cmd+Shift+Del)

### Dados desapareceram
Dados salvos no localStorage. Se limpou cache do browser, serão perdidos. Use "Exportar" regularmente.

---

## 📈 Próximas funcionalidades

- Sync automático com Google Sheets
- Notificações para follow-ups atrasados
- Histórico de alterações
- Dashboard compartilhável sem login
- Importar dados de Excel

---

## 📧 Suporte

Se tiver dúvidas ou bugs, abra uma issue no GitHub:
https://github.com/SEU_USUARIO/crm-ergonomica/issues

---

**Versão**: 1.0.0  
**Última atualização**: 2026-01-30  
**Status**: ✅ Pronto para produção
